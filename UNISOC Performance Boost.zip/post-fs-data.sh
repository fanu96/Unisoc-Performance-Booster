#!/system/bin/sh

chmod 0664 /sys/class/devfreq/60000000.gpu/*
echo 812000000 > /sys/class/devfreq/60000000.gpu/min_freq
echo 936000000 > /sys/class/devfreq/60000000.gpu/max_freq
echo 814400000 > /sys/class/devfreq/60000000.gpu/target_freq
echo 50 > /sys/class/devfreq/60000000.gpu/polling_interval
    
chmod 0664 /sys/class/display/dispc0/*
echo 80 > /sys/class/display/dispc0/actual_fps
    
chmod 0664 /sys/class/display/dphy0/*
echo 800000 > /sys/class/display/dphy0/freq
echo "vdsp_dvfs" > /sys/class/devfreq/60000000.gpu/governor
echo 936000000 > /sys/class/devfreq/vdsp/min_freq
echo 936000000 > /sys/class/devfreq/vdsp/max_freq
        

    sleep 2
done